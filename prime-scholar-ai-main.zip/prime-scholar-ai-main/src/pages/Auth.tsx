import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { GraduationCap, Users, Shield, ArrowLeft, Chrome } from "lucide-react";

const Auth = () => {
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState<'student' | 'admin' | null>(null);
  const [adminCredentials, setAdminCredentials] = useState({ id: '', password: '' });

  const handleStudentLogin = () => {
    // In a real app, this would trigger Google OAuth
    console.log("Google OAuth login initiated");
    navigate("/student-dashboard");
  };

  const handleAdminLogin = () => {
    if (adminCredentials.id === 'admin' && adminCredentials.password === 'admin1234') {
      navigate("/admin-dashboard");
    } else {
      alert("Invalid admin credentials");
    }
  };

  if (!selectedRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-accent/10 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl animate-fade-in">
          {/* Header */}
          <div className="text-center mb-12">
            <Button 
              variant="ghost" 
              onClick={() => navigate("/")}
              className="absolute top-6 left-6 hover-lift"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
            
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-glow rounded-xl flex items-center justify-center">
                <GraduationCap className="w-7 h-7 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">PM Scholarship Portal</h1>
                <p className="text-muted-foreground">Choose your access type</p>
              </div>
            </div>
          </div>

          {/* Role Selection */}
          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {/* Student Login */}
            <Card 
              className="card-feature cursor-pointer group hover:scale-105"
              onClick={() => setSelectedRole('student')}
            >
              <CardHeader className="text-center pb-4">
                <div className="w-20 h-20 bg-gradient-to-br from-primary to-primary-glow rounded-3xl flex items-center justify-center mx-auto mb-4 group-hover:animate-glow">
                  <Users className="w-10 h-10 text-primary-foreground" />
                </div>
                <CardTitle className="text-2xl text-foreground">Student Login</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Access your personalized dashboard to discover scholarship opportunities, 
                  manage your profile, and connect with verified companies.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Chrome className="w-4 h-4 mr-2" />
                    Secure Google Authentication
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <GraduationCap className="w-4 h-4 mr-2" />
                    AI-Powered Recommendations
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Admin Login */}
            <Card 
              className="card-feature cursor-pointer group hover:scale-105"
              onClick={() => setSelectedRole('admin')}
            >
              <CardHeader className="text-center pb-4">
                <div className="w-20 h-20 bg-gradient-to-br from-accent to-gold rounded-3xl flex items-center justify-center mx-auto mb-4 group-hover:animate-glow">
                  <Shield className="w-10 h-10 text-accent-foreground" />
                </div>
                <CardTitle className="text-2xl text-foreground">Admin Access</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Manage user accounts, company partnerships, monitor system performance, 
                  and oversee the scholarship recommendation platform.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Shield className="w-4 h-4 mr-2" />
                    Administrative Dashboard
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Users className="w-4 h-4 mr-2" />
                    User & Company Management
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-accent/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-fade-in">
        <Button 
          variant="ghost" 
          onClick={() => setSelectedRole(null)}
          className="mb-6 hover-lift"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Selection
        </Button>

        <Card className="card-elegant">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary-glow rounded-2xl flex items-center justify-center mx-auto mb-4">
              {selectedRole === 'student' ? (
                <Users className="w-8 h-8 text-primary-foreground" />
              ) : (
                <Shield className="w-8 h-8 text-primary-foreground" />
              )}
            </div>
            <CardTitle className="text-2xl">
              {selectedRole === 'student' ? 'Student Login' : 'Admin Login'}
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {selectedRole === 'student' ? (
              <>
                <div className="text-center text-muted-foreground">
                  Sign in with your Google account to access your personalized scholarship dashboard
                </div>
                
                <Separator />
                
                <Button 
                  onClick={handleStudentLogin}
                  className="w-full btn-hero flex items-center justify-center space-x-3 py-6"
                >
                  <Chrome className="w-5 h-5" />
                  <span>Continue with Google</span>
                </Button>
                
                <p className="text-xs text-muted-foreground text-center">
                  By continuing, you agree to our Terms of Service and Privacy Policy
                </p>
              </>
            ) : (
              <>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="admin-id">Admin ID</Label>
                    <Input
                      id="admin-id"
                      type="text"
                      placeholder="Enter admin ID"
                      value={adminCredentials.id}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, id: e.target.value }))}
                      className="mt-2"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="admin-password">Password</Label>
                    <Input
                      id="admin-password"
                      type="password"
                      placeholder="Enter password"
                      value={adminCredentials.password}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, password: e.target.value }))}
                      className="mt-2"
                    />
                  </div>
                </div>
                
                <Button 
                  onClick={handleAdminLogin}
                  className="w-full btn-accent py-6"
                  disabled={!adminCredentials.id || !adminCredentials.password}
                >
                  Sign In as Admin
                </Button>
                
                <p className="text-xs text-muted-foreground text-center">
                  Default credentials: admin / admin1234
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Auth;