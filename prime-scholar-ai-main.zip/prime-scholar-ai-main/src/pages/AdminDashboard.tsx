import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Shield, 
  Users, 
  Building, 
  LogOut, 
  GraduationCap, 
  Mail,
  Phone,
  MapPin,
  Star,
  TrendingUp,
  FileText,
  Bell
} from "lucide-react";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  const handleLogout = () => {
    navigate("/");
  };

  const mockUsers = [
    {
      id: 1,
      name: "Rahul Sharma",
      email: "rahul.sharma@email.com",
      college: "IIT Delhi",
      stream: "Computer Science",
      cgpa: "8.4",
      status: "Active",
      joinedDate: "2024-01-15"
    },
    {
      id: 2,
      name: "Priya Patel",
      email: "priya.patel@email.com",
      college: "IIT Mumbai",
      stream: "Electronics",
      cgpa: "8.7",
      status: "Active",
      joinedDate: "2024-01-18"
    },
    {
      id: 3,
      name: "Arjun Singh",
      email: "arjun.singh@email.com",
      college: "NIT Trichy",
      stream: "Mechanical",
      cgpa: "8.1",
      status: "Pending",
      joinedDate: "2024-01-20"
    }
  ];

  const mockCompanies = [
    {
      id: 1,
      name: "Tech Innovators Ltd",
      contact: "+91 9876543210",
      email: "hr@techinnovators.com",
      location: "Bangalore",
      positions: 5,
      status: "Verified",
      rating: 4.8
    },
    {
      id: 2,
      name: "Digital Solutions Corp",
      contact: "+91 9876543211",
      email: "careers@digitalsolutions.com",
      location: "Hyderabad",
      positions: 3,
      status: "Verified",
      rating: 4.6
    },
    {
      id: 3,
      name: "Green Energy Systems",
      contact: "+91 9876543212",
      email: "jobs@greenenergy.com",
      location: "Pune",
      positions: 2,
      status: "Pending",
      rating: 4.5
    }
  ];

  const mockFeedbacks = [
    {
      id: 1,
      user: "Rahul Sharma",
      message: "The platform is excellent! Found perfect internship opportunities.",
      date: "2024-01-22",
      rating: 5
    },
    {
      id: 2,
      user: "Priya Patel",
      message: "Great AI recommendations, but could use more filtering options.",
      date: "2024-01-21",
      rating: 4
    }
  ];

  const renderOverview = () => (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="card-elegant animate-bounce-in hover:scale-105 transition-all duration-500" style={{animationDelay: '0.1s'}}>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-glow rounded-xl flex items-center justify-center mx-auto mb-4 animate-float shadow-lg">
              <Users className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="text-4xl font-display font-bold text-primary mb-2 animate-pulse-slow">{mockUsers.length}</div>
            <div className="text-muted-foreground font-medium">Total Students</div>
            <div className="flex items-center justify-center mt-2 text-green-600 text-sm font-medium">
              <TrendingUp className="w-4 h-4 mr-1" />
              +12% this month
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-elegant animate-bounce-in hover:scale-105 transition-all duration-500" style={{animationDelay: '0.2s'}}>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-accent to-gold rounded-xl flex items-center justify-center mx-auto mb-4 animate-float shadow-lg" style={{animationDelay: '1s'}}>
              <Building className="w-6 h-6 text-accent-foreground" />
            </div>
            <div className="text-4xl font-display font-bold text-accent mb-2 animate-pulse-slow" style={{animationDelay: '0.5s'}}>{mockCompanies.length}</div>
            <div className="text-muted-foreground font-medium">Partner Companies</div>
            <div className="flex items-center justify-center mt-2 text-green-600 text-sm font-medium">
              <TrendingUp className="w-4 h-4 mr-1" />
              +8% this month
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-elegant animate-bounce-in hover:scale-105 transition-all duration-500" style={{animationDelay: '0.3s'}}>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-primary-glow to-accent rounded-xl flex items-center justify-center mx-auto mb-4 animate-float shadow-lg" style={{animationDelay: '2s'}}>
              <TrendingUp className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="text-4xl font-display font-bold text-primary-glow mb-2 animate-pulse-slow" style={{animationDelay: '1s'}}>47</div>
            <div className="text-muted-foreground font-medium">Active Matches</div>
            <div className="flex items-center justify-center mt-2 text-green-600 text-sm font-medium">
              <TrendingUp className="w-4 h-4 mr-1" />
              +24% this week
            </div>
          </CardContent>
        </Card>
        
        <Card className="card-elegant animate-bounce-in hover:scale-105 transition-all duration-500" style={{animationDelay: '0.4s'}}>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-gold to-accent rounded-xl flex items-center justify-center mx-auto mb-4 animate-float shadow-lg" style={{animationDelay: '3s'}}>
              <Star className="w-6 h-6 text-gold-foreground" />
            </div>
            <div className="text-4xl font-display font-bold text-gold mb-2 animate-pulse-slow" style={{animationDelay: '1.5s'}}>4.7</div>
            <div className="text-muted-foreground font-medium">Platform Rating</div>
            <div className="flex items-center justify-center mt-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className={`w-4 h-4 animate-pulse ${star <= 4 ? 'text-gold fill-current' : 'text-muted-foreground'}`} style={{animationDelay: `${star * 0.1}s`}} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="card-elegant">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2 text-primary" />
              Recent Student Registrations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockUsers.slice(0, 3).map((user) => (
                <div key={user.id} className="flex items-center space-x-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary-glow rounded-full flex items-center justify-center text-primary-foreground font-semibold">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.college}</p>
                  </div>
                  <Badge variant={user.status === 'Active' ? 'default' : 'secondary'}>
                    {user.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="card-elegant">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2 text-accent" />
              Recent Feedback
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockFeedbacks.map((feedback) => (
                <div key={feedback.id} className="p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-foreground">{feedback.user}</p>
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star key={star} className={`w-3 h-3 ${star <= feedback.rating ? 'text-gold fill-current' : 'text-muted-foreground'}`} />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">{feedback.message}</p>
                  <p className="text-xs text-muted-foreground">{feedback.date}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h2 className="text-4xl font-display font-bold text-foreground bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Student Management</h2>
        <Button className="btn-accent">
          Export Data
        </Button>
      </div>

      <Card className="card-elegant">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>College</TableHead>
                <TableHead>Stream</TableHead>
                <TableHead>CGPA</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockUsers.map((user) => (
                <TableRow key={user.id} className="hover:bg-muted/50">
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary-glow rounded-full flex items-center justify-center text-primary-foreground text-sm font-semibold">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{user.college}</TableCell>
                  <TableCell>{user.stream}</TableCell>
                  <TableCell>{user.cgpa}</TableCell>
                  <TableCell>
                    <Badge variant={user.status === 'Active' ? 'default' : 'secondary'}>
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{user.joinedDate}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );

  const renderCompanies = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h2 className="text-4xl font-display font-bold text-foreground bg-gradient-to-r from-accent to-gold bg-clip-text text-transparent">Company Management</h2>
        <Button className="btn-accent">
          Add Company
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockCompanies.map((company) => (
          <Card key={company.id} className="card-feature">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{company.name}</CardTitle>
                <Badge variant={company.status === 'Verified' ? 'default' : 'secondary'}>
                  {company.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Mail className="w-4 h-4 mr-2" />
                  {company.email}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Phone className="w-4 h-4 mr-2" />
                  {company.contact}
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4 mr-2" />
                  {company.location}
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t">
                <div className="text-center">
                  <div className="font-semibold text-primary">{company.positions}</div>
                  <div className="text-xs text-muted-foreground">Open Positions</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-accent">{company.rating}</div>
                  <div className="text-xs text-muted-foreground">Rating</div>
                </div>
              </div>
              
              <div className="flex gap-2 pt-2">
                <Button size="sm" className="btn-hero flex-1">
                  View Details
                </Button>
                <Button size="sm" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                  Edit
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-accent/10 font-sans">
      {/* Header */}
      <header className="bg-card/50 backdrop-blur-sm border-b sticky top-0 z-50 animate-slide-up">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4 animate-slide-in-left">
              <div className="w-12 h-12 bg-gradient-to-br from-accent to-gold rounded-xl flex items-center justify-center animate-float shadow-lg">
                <Shield className="w-7 h-7 text-accent-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-display font-bold text-foreground bg-gradient-to-r from-accent to-gold bg-clip-text text-transparent">
                  Admin Dashboard
                </h1>
                <p className="text-sm text-muted-foreground font-medium">PM Scholarship Portal Management</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 animate-slide-in-right">
              <Button variant="ghost" size="sm" className="relative hover-lift">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse"></span>
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                className="text-muted-foreground hover:text-foreground hover-lift transition-all duration-300"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <Card className="card-elegant sticky top-24">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  <Button
                    variant={activeTab === 'overview' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'overview' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('overview')}
                  >
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Overview
                  </Button>
                  
                  <Button
                    variant={activeTab === 'users' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'users' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('users')}
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Students
                  </Button>
                  
                  <Button
                    variant={activeTab === 'companies' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'companies' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('companies')}
                  >
                    <Building className="w-4 h-4 mr-2" />
                    Companies
                  </Button>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && renderOverview()}
            {activeTab === 'users' && renderUsers()}
            {activeTab === 'companies' && renderCompanies()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;