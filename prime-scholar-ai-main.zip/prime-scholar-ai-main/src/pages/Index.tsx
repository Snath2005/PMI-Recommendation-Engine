import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Award, Users, TrendingUp, ArrowRight, Star } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: GraduationCap,
      title: "Smart Matching",
      description: "AI-powered recommendation engine that matches students with perfect scholarship opportunities based on their profile and preferences."
    },
    {
      icon: Award,
      title: "Prime Minister Scholarships",
      description: "Access to exclusive government scholarship programs designed to support academic excellence and career development."
    },
    {
      icon: Users,
      title: "Verified Companies",
      description: "Connect with verified organizations offering internships and career opportunities aligned with your academic goals."
    },
    {
      icon: TrendingUp,
      title: "Career Growth",
      description: "Track your progress and get personalized recommendations to enhance your academic and professional journey."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-accent/10">
      {/* Header */}
      <header className="py-6 px-4 sm:px-6 lg:px-8">
        <nav className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">PM Scholarship</h1>
              <p className="text-xs text-muted-foreground">Recommendation Engine</p>
            </div>
          </div>
          
          <Button 
            onClick={() => navigate("/auth")}
            className="btn-hero hover:animate-glow"
          >
            Get Started
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-fade-in">
            <div className="inline-flex items-center space-x-2 bg-accent/10 px-4 py-2 rounded-full mb-8">
              <Star className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent-foreground">AI-Powered Matching System</span>
            </div>
            
            <h1 className="text-4xl sm:text-6xl font-bold text-foreground mb-6 leading-tight">
              Welcome to the 
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Prime Minister</span>
              <br />
              <span className="text-3xl sm:text-5xl">Scholarship Portal</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              Discover perfect scholarship opportunities with our AI-powered recommendation engine. 
              Connect students with verified companies and unlock your potential for academic and career excellence.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => navigate("/auth")}
                className="btn-hero text-lg px-8 py-6 hover:animate-glow"
              >
                Start Your Journey
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground text-lg px-8 py-6"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Empowering Your Academic Journey
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our comprehensive platform combines cutting-edge AI technology with verified opportunities 
              to create the perfect pathway for your success.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="card-feature group animate-fade-in" style={{animationDelay: `${index * 100}ms`}}>
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary-glow rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <feature.icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <Card className="card-elegant bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Ready to Transform Your Future?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join thousands of students who have discovered their perfect scholarship opportunities 
                through our AI-powered platform.
              </p>
              <Button 
                size="lg"
                onClick={() => navigate("/auth")}
                className="btn-hero text-lg px-8 py-6 hover:animate-glow"
              >
                Get Started Today
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground">PM Scholarship Portal</span>
          </div>
          <p className="text-muted-foreground">
            Empowering students through AI-powered scholarship recommendations
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;