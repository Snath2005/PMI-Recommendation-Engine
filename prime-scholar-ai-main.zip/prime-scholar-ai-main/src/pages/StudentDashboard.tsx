import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  User, 
  FileText, 
  Search, 
  Bell, 
  LogOut, 
  GraduationCap, 
  MapPin, 
  Phone, 
  Mail,
  Edit,
  Star,
  Building,
  DollarSign,
  Filter,
  ExternalLink,
  Clock,
  Users,
  Globe,
  Code,
  Brain,
  Lightbulb
} from "lucide-react";

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [locationFilter, setLocationFilter] = useState('all');
  const [stipendFilter, setStipendFilter] = useState('all');

  const handleLogout = () => {
    navigate("/");
  };

  const mockRecommendations = [
    {
      id: 1,
      company: "Tech Innovators Ltd",
      position: "Software Development Intern",
      stipend: "₹15,000 - ₹20,000",
      location: "Bangalore",
      match: 95,
      requirements: ["React", "Node.js", "CGPA > 7.5"],
      description: "Join our dynamic team to work on cutting-edge web applications and gain hands-on experience in modern technologies."
    },
    {
      id: 2,
      company: "Digital Solutions Corp",
      position: "Data Science Intern",
      stipend: "₹12,000 - ₹18,000",
      location: "Hyderabad",
      match: 88,
      requirements: ["Python", "Machine Learning", "Statistics"],
      description: "Work on real-world data science projects and contribute to our AI-driven solutions for enterprise clients."
    },
    {
      id: 3,
      company: "Green Energy Systems",
      position: "Research & Development Intern",
      stipend: "₹10,000 - ₹15,000",
      location: "Pune",
      match: 82,
      requirements: ["Engineering Background", "Research Skills", "Environmental Science"],
      description: "Contribute to sustainable energy solutions and participate in groundbreaking research initiatives."
    }
  ];

  const mockProfile = {
    name: "Rahul Sharma",
    email: "rahul.sharma@email.com",
    phone: "+91 9876543210",
    college: "Indian Institute of Technology, Delhi",
    stream: "Computer Science & Engineering",
    cgpa: "8.4",
    address: "New Delhi, India",
    skills: [
      "Full Stack Development",
      "Web Developer", 
      "Frontend Developer",
      "Backend Developer",
      "Data Scientist",
      "Mobile App Developer",
      "Machine Learning",
      "UI/UX Design",
      "DevOps",
      "Cloud Computing"
    ],
    interests: [
      "Artificial Intelligence",
      "Blockchain Technology",
      "Cybersecurity",
      "Internet of Things",
      "Augmented Reality",
      "Software Architecture"
    ]
  };

  const mockCompanies = [
    {
      id: 1,
      name: "Tech Innovators Ltd",
      logo: "TI",
      industry: "Information Technology",
      location: "Bangalore",
      website: "www.techinnovators.com",
      email: "hr@techinnovators.com",
      phone: "+91 80 1234 5678",
      description: "Leading technology company specializing in AI-driven solutions and web development.",
      openPositions: 5,
      activeInternships: [
        {
          title: "Software Development Intern",
          stipend: "₹15,000 - ₹20,000",
          duration: "6 months",
          requirements: ["React", "Node.js", "CGPA > 7.5"]
        },
        {
          title: "UI/UX Design Intern",
          stipend: "₹12,000 - ₹18,000",
          duration: "4 months",
          requirements: ["Figma", "Design Portfolio", "Creative Thinking"]
        }
      ]
    },
    {
      id: 2,
      name: "Digital Solutions Corp",
      logo: "DS",
      industry: "Data Analytics",
      location: "Hyderabad",
      website: "www.digitalsolutions.com",
      email: "careers@digitalsolutions.com",
      phone: "+91 40 9876 5432",
      description: "Data-driven company providing analytics solutions for Fortune 500 companies.",
      openPositions: 3,
      activeInternships: [
        {
          title: "Data Science Intern",
          stipend: "₹12,000 - ₹18,000",
          duration: "6 months",
          requirements: ["Python", "Machine Learning", "Statistics"]
        }
      ]
    },
    {
      id: 3,
      name: "Green Energy Systems",
      logo: "GE",
      industry: "Renewable Energy",
      location: "Pune",
      website: "www.greenenergy.com",
      email: "internships@greenenergy.com",
      phone: "+91 20 5555 7777",
      description: "Pioneering sustainable energy solutions for a greener future.",
      openPositions: 4,
      activeInternships: [
        {
          title: "Research & Development Intern",
          stipend: "₹10,000 - ₹15,000",
          duration: "5 months",
          requirements: ["Engineering Background", "Research Skills", "Environmental Science"]
        }
      ]
    },
    {
      id: 4,
      name: "FinTech Innovations",
      logo: "FI",
      industry: "Financial Technology",
      location: "Mumbai",
      website: "www.fintechinnovations.com",
      email: "talent@fintechinnovations.com",
      phone: "+91 22 8888 9999",
      description: "Revolutionary financial technology solutions for modern banking.",
      openPositions: 6,
      activeInternships: [
        {
          title: "Backend Development Intern",
          stipend: "₹18,000 - ₹25,000",
          duration: "6 months",
          requirements: ["Java", "Spring Boot", "Microservices"]
        },
        {
          title: "Product Management Intern",
          stipend: "₹15,000 - ₹22,000",
          duration: "4 months",
          requirements: ["Product Strategy", "Market Research", "Communication Skills"]
        }
      ]
    },
    {
      id: 5,
      name: "HealthCare Solutions",
      logo: "HC",
      industry: "Healthcare Technology",
      location: "Chennai",
      website: "www.healthcaresolutions.com",
      email: "hr@healthcaresolutions.com",
      phone: "+91 44 7777 6666",
      description: "Healthcare technology solutions improving patient care and medical efficiency.",
      openPositions: 2,
      activeInternships: [
        {
          title: "Mobile App Development Intern",
          stipend: "₹14,000 - ₹19,000",
          duration: "5 months",
          requirements: ["React Native", "Flutter", "Healthcare Domain Knowledge"]
        }
      ]
    }
  ];

  const filteredCompanies = mockCompanies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         company.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         company.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesLocation = locationFilter === 'all' || company.location === locationFilter;
    
    const matchesStipend = stipendFilter === 'all' || 
      company.activeInternships.some(internship => {
        if (stipendFilter === 'low') return internship.stipend.includes('10,000') || internship.stipend.includes('12,000');
        if (stipendFilter === 'medium') return internship.stipend.includes('15,000') || internship.stipend.includes('18,000');
        if (stipendFilter === 'high') return internship.stipend.includes('20,000') || internship.stipend.includes('25,000');
        return true;
      });
    
    return matchesSearch && matchesLocation && matchesStipend;
  });

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 animate-fade-in">
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Welcome back, {mockProfile.name}! 👋
        </h2>
        <p className="text-muted-foreground text-lg">
          You have {mockRecommendations.length} new scholarship recommendations waiting for you.
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="card-elegant">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">{mockRecommendations.length}</div>
            <div className="text-muted-foreground">New Recommendations</div>
          </CardContent>
        </Card>
        <Card className="card-elegant">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-accent mb-2">95%</div>
            <div className="text-muted-foreground">Best Match</div>
          </CardContent>
        </Card>
        <Card className="card-elegant">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary-glow mb-2">12</div>
            <div className="text-muted-foreground">Applications Sent</div>
          </CardContent>
        </Card>
        <Card className="card-elegant">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-gold mb-2">3</div>
            <div className="text-muted-foreground">Interviews Scheduled</div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Recommendations */}
      <div>
        <h3 className="text-2xl font-bold text-foreground mb-6">Recommended For You</h3>
        <div className="space-y-6">
          {mockRecommendations.map((rec) => (
            <Card key={rec.id} className="card-feature hover:scale-[1.02]">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-xl font-semibold text-foreground mb-2">{rec.company}</h4>
                    <p className="text-lg text-primary font-medium">{rec.position}</p>
                  </div>
                  <Badge className="bg-gradient-to-r from-accent to-gold text-accent-foreground">
                    {rec.match}% Match
                  </Badge>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center text-muted-foreground">
                    <DollarSign className="w-4 h-4 mr-2" />
                    {rec.stipend}
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2" />
                    {rec.location}
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Building className="w-4 h-4 mr-2" />
                    Internship
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-4">{rec.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {rec.requirements.map((req, index) => (
                    <Badge key={index} variant="secondary">
                      {req}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex gap-3">
                  <Button className="btn-hero flex-1">
                    View Details
                  </Button>
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                    Contact Company
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCompanies = () => (
    <div className="space-y-8 animate-fade-in">
      {/* Search and Filters */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-6">
        <h2 className="text-3xl font-bold text-foreground mb-6">Browse Companies</h2>
        
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search companies by name, industry, or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
          
          <Select value={locationFilter} onValueChange={setLocationFilter}>
            <SelectTrigger className="md:w-48 h-12">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="Bangalore">Bangalore</SelectItem>
              <SelectItem value="Hyderabad">Hyderabad</SelectItem>
              <SelectItem value="Pune">Pune</SelectItem>
              <SelectItem value="Mumbai">Mumbai</SelectItem>
              <SelectItem value="Chennai">Chennai</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={stipendFilter} onValueChange={setStipendFilter}>
            <SelectTrigger className="md:w-48 h-12">
              <SelectValue placeholder="Stipend Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stipends</SelectItem>
              <SelectItem value="low">₹10,000 - ₹15,000</SelectItem>
              <SelectItem value="medium">₹15,000 - ₹20,000</SelectItem>
              <SelectItem value="high">₹20,000+</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="mt-4 text-muted-foreground">
          Found {filteredCompanies.length} companies matching your criteria
        </div>
      </div>

      {/* Companies Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredCompanies.map((company) => (
          <Card key={company.id} className="card-feature hover:scale-[1.02] transition-transform duration-300">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary-glow rounded-xl flex items-center justify-center">
                    <span className="text-2xl font-bold text-primary-foreground">{company.logo}</span>
                  </div>
                  <div>
                    <CardTitle className="text-xl">{company.name}</CardTitle>
                    <p className="text-muted-foreground">{company.industry}</p>
                  </div>
                </div>
                <Badge className="bg-gradient-to-r from-accent to-gold text-accent-foreground">
                  {company.openPositions} Open Positions
                </Badge>
              </div>
              
              <p className="text-sm text-muted-foreground leading-relaxed">
                {company.description}
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Company Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span>{company.location}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Globe className="w-4 h-4 text-primary" />
                  <span className="truncate">{company.website}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4 text-primary" />
                  <span className="truncate">{company.email}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-primary" />
                  <span>{company.phone}</span>
                </div>
              </div>
              
              {/* Active Internships */}
              <div>
                <h4 className="font-semibold text-foreground mb-3 flex items-center">
                  <Users className="w-4 h-4 mr-2" />
                  Active Internships ({company.activeInternships.length})
                </h4>
                <div className="space-y-3">
                  {company.activeInternships.map((internship, index) => (
                    <div key={index} className="bg-secondary/50 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="font-medium text-foreground">{internship.title}</h5>
                        <Badge variant="secondary" className="text-xs">
                          {internship.duration}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                        <div className="flex items-center">
                          <DollarSign className="w-3 h-3 mr-1" />
                          {internship.stipend}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {internship.duration}
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {internship.requirements.map((req, reqIndex) => (
                          <Badge key={reqIndex} variant="outline" className="text-xs">
                            {req}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex gap-3 pt-2">
                <Button className="btn-hero flex-1">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Details
                </Button>
                <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                  Contact
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {filteredCompanies.length === 0 && (
        <Card className="card-elegant">
          <CardContent className="p-12 text-center">
            <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">No Companies Found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search criteria or filters to find more companies.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderProfile = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-foreground">My Profile</h2>
        <Button className="btn-accent">
          <Edit className="w-4 h-4 mr-2" />
          Edit Profile
        </Button>
      </div>

      <Card className="card-elegant">
        <CardHeader className="text-center">
          <Avatar className="w-24 h-24 mx-auto mb-4">
            <AvatarImage src="" />
            <AvatarFallback className="text-2xl bg-gradient-to-br from-primary to-primary-glow text-primary-foreground">
              {mockProfile.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <CardTitle className="text-2xl">{mockProfile.name}</CardTitle>
          <p className="text-muted-foreground">{mockProfile.stream}</p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{mockProfile.email}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="font-medium">{mockProfile.phone}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <GraduationCap className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">CGPA</p>
                  <p className="font-medium">{mockProfile.cgpa}</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Building className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">College</p>
                  <p className="font-medium">{mockProfile.college}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Address</p>
                  <p className="font-medium">{mockProfile.address}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Skills & Interests Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            {/* Skills */}
            <Card className="card-elegant">
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <Code className="w-5 h-5 mr-2 text-primary" />
                  Technical Skills
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {mockProfile.skills.map((skill, index) => (
                    <Badge 
                      key={index} 
                      className="bg-gradient-to-r from-primary/20 to-primary-glow/20 text-primary border-primary/30 hover:bg-primary hover:text-primary-foreground transition-colors duration-200"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Interests */}
            <Card className="card-elegant">
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-accent" />
                  Areas of Interest
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {mockProfile.interests.map((interest, index) => (
                    <Badge 
                      key={index} 
                      className="bg-gradient-to-r from-accent/20 to-gold/20 text-accent border-accent/30 hover:bg-accent hover:text-accent-foreground transition-colors duration-200"
                    >
                      {interest}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-accent/10">
      {/* Header */}
      <header className="bg-card/50 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Student Dashboard</h1>
                <p className="text-sm text-muted-foreground">PM Scholarship Portal</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full"></span>
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                className="text-muted-foreground hover:text-foreground"
              >
                <LogOut className="w-5 h-5 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <Card className="card-elegant sticky top-24">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  <Button
                    variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'dashboard' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('dashboard')}
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                  
                  <Button
                    variant={activeTab === 'profile' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'profile' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('profile')}
                  >
                    <User className="w-4 h-4 mr-2" />
                    My Profile
                  </Button>
                  
                  <Button
                    variant={activeTab === 'companies' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'companies' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('companies')}
                  >
                    <Building className="w-4 h-4 mr-2" />
                    Browse Companies
                  </Button>
                  
                  <Button
                    variant={activeTab === 'documents' ? 'default' : 'ghost'}
                    className={`w-full justify-start ${activeTab === 'documents' ? 'btn-hero' : ''}`}
                    onClick={() => setActiveTab('documents')}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Documents
                  </Button>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'dashboard' && renderDashboard()}
            {activeTab === 'profile' && renderProfile()}
            {activeTab === 'companies' && renderCompanies()}
            {activeTab === 'documents' && (
              <div className="animate-fade-in">
                <h2 className="text-3xl font-bold text-foreground mb-6">My Documents</h2>
                <Card className="card-elegant">
                  <CardContent className="p-12 text-center">
                    <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-foreground mb-2">Upload Your Documents</h3>
                    <p className="text-muted-foreground mb-6">
                      Upload your certificates, transcripts, and other relevant documents to enhance your profile
                    </p>
                    <Button className="btn-accent">
                      Upload Documents
                    </Button>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;